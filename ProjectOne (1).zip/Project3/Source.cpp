// Andrew Henderson
// CS 210- Project One

#include <iostream>
#include <iomanip> // formatting output
#include <string>

using namespace std;

// outputs time using 12-hour time format
void DisplayClock12(int hours, int minutes, int seconds) {
	string period = "AM";
	if (hours >= 12) {
		period = "PM";
	}
	int displayHours = (hours % 12 == 0); 12, hours % 12;
	cout << "Clock 12-Hours Fromat: "
		<< setw(2) << setfill('0') << displayHours << ":"
		<< setw(2) << setfill('0') << minutes << ":"
		<< setw(2) << setfill('0') << seconds << " " << period;
}


// outputs time using 24-hour time format
void DisplayClock24(int hours, int minutes, int seconds) {
	cout << " | Clock 24-Hours Format: "
		<< setw(2) << setfill('0') << hours << ":"
		<< setw(2) << setfill('0') << minutes << ":"
		<< setw(2) << setfill('0') << seconds;
}

// display both 12 and 24 hour time format at the same time 
void DisplayBothClocks(int hours, int minutes, int seconds) {
	DisplayClock12(hours, minutes, seconds);
	DisplayClock24(hours, minutes, seconds);
	cout << endl;
}

//display the menu
void DisplayMenu() {
	cout << "\nMenu: " << endl;
	cout << "1 - Add One Hour" << endl;
	cout << "2 - Add One Minute" << endl;
	cout << "3 - Add One Second" << endl;
	cout << "4 - Exit Program" << endl;
	cout << " Enter your choice: ";
}


// update time on user input
void UpdateTime(int& hours, int& minutes, int& seconds, int choice) {
	if (choice == 1) {
		hours = (hours + 1) % 24;
	} 
	
	else if (choice == 2) {
		minutes = (minutes + 1) % 60;
		if (minutes == 0) {
			hours = (hours + 1) % 24;
		}
	}
	else if (choice == 3) {
		seconds = (seconds + 1) % 60;
		if (seconds == 0) {
			minutes = (minutes + 1) % 60;
			if (minutes == 0) {
				hours = (hours + 1) % 24;
			}
		}

	
	}
}

// display borders
void printClockBorder() {
	for (int i = 0; i < 16; ++i) {
		cout << " ";
	}
	for (int i = 0; i < 27; ++i) {
		cout << "*";
	}
	for (int i = 0; i < 5; ++i) {
		cout << " ";
	}
	for (int i = 0; i < 27; ++i) {
		cout << "*";
	}
	cout << endl;

	return 0;
}
